#include <stdlib.h>
struct fptr
{
int (*p_fptr)(int, int);
};
int plus(int a, int b) {
   return a+b;
}

int minus(int a, int b) {
   return a-b;
}

int clever(int x) {
    int (*a_fptr)(int, int) = plus;
    int (*s_fptr)(int, int) = minus;
    struct fptr t_fptr={0};

    int op1=1, op2=2;

    if (x == 3) {
       t_fptr.p_fptr = a_fptr;
    } else {
       t_fptr.p_fptr = s_fptr;
    }

    if (t_fptr.p_fptr != NULL) {
       unsigned result = t_fptr.p_fptr(op1, op2);
    }  
   return 0;
}

/// 28 : plus, minus


%add = add nsw i32 %a, %b, !dbg !18

in :
out :
----PrintResult---
----ENDPrintResult---
%sub = sub nsw i32 %a, %b, !dbg !18

in :
out :
----PrintResult---
----ENDPrintResult---
%cmp = icmp eq i32 %x, 3, !dbg !32
%0 = bitcast %struct.fptr* %t_fptr to i8*, !dbg !27
%t_fptr = alloca %struct.fptr, align 8
%p_fptr = getelementptr inbounds %struct.fptr, %struct.fptr* %t_fptr, i32 0, i32 0, !dbg !35
%t_fptr = alloca %struct.fptr, align 8
------predblock------

entry:
%t_fptr = alloca %struct.fptr, align 8
call void @llvm.dbg.value(metadata i32 %x, i64 0, metadata !13, metadata !14), !dbg !15
call void @llvm.dbg.value(metadata i32 (i32, i32)* @plus, i64 0, metadata !16, metadata !14), !dbg !20
call void @llvm.dbg.value(metadata i32 (i32, i32)* @minus, i64 0, metadata !21, metadata !14), !dbg !22
call void @llvm.dbg.declare(metadata %struct.fptr* %t_fptr, metadata !23, metadata !14), !dbg !27
%0 = bitcast %struct.fptr* %t_fptr to i8*, !dbg !27
call void @llvm.memset.p0i8.i64(i8* %0, i8 0, i64 8, i32 8, i1 false), !dbg !27
call void @llvm.dbg.value(metadata i32 1, i64 0, metadata !28, metadata !14), !dbg !29
call void @llvm.dbg.value(metadata i32 2, i64 0, metadata !30, metadata !14), !dbg !31
%cmp = icmp eq i32 %x, 3, !dbg !32
br i1 %cmp, label %if.then, label %if.else, !dbg !34

%cmp = icmp eq i32 %x, 3, !dbg !32
%0 = bitcast %struct.fptr* %t_fptr to i8*, !dbg !27
%t_fptr = alloca %struct.fptr, align 8
%p_fptr1 = getelementptr inbounds %struct.fptr, %struct.fptr* %t_fptr, i32 0, i32 0, !dbg !39
%t_fptr = alloca %struct.fptr, align 8
------predblock------

entry:
%t_fptr = alloca %struct.fptr, align 8
call void @llvm.dbg.value(metadata i32 %x, i64 0, metadata !13, metadata !14), !dbg !15
call void @llvm.dbg.value(metadata i32 (i32, i32)* @plus, i64 0, metadata !16, metadata !14), !dbg !20
call void @llvm.dbg.value(metadata i32 (i32, i32)* @minus, i64 0, metadata !21, metadata !14), !dbg !22
call void @llvm.dbg.declare(metadata %struct.fptr* %t_fptr, metadata !23, metadata !14), !dbg !27
%0 = bitcast %struct.fptr* %t_fptr to i8*, !dbg !27
call void @llvm.memset.p0i8.i64(i8* %0, i8 0, i64 8, i32 8, i1 false), !dbg !27
call void @llvm.dbg.value(metadata i32 1, i64 0, metadata !28, metadata !14), !dbg !29
call void @llvm.dbg.value(metadata i32 2, i64 0, metadata !30, metadata !14), !dbg !31
%cmp = icmp eq i32 %x, 3, !dbg !32
br i1 %cmp, label %if.then, label %if.else, !dbg !34

%cmp = icmp eq i32 %x, 3, !dbg !32
%0 = bitcast %struct.fptr* %t_fptr to i8*, !dbg !27
%t_fptr = alloca %struct.fptr, align 8
%cmp3 = icmp ne i32 (i32, i32)* %1, null, !dbg !44
%1 = load i32 (i32, i32)*, i32 (i32, i32)** %p_fptr2, align 8, !dbg !42
%p_fptr2 = getelementptr inbounds %struct.fptr, %struct.fptr* %t_fptr, i32 0, i32 0, !dbg !42
%t_fptr = alloca %struct.fptr, align 8
------predblock------

if.else:                                          ; preds = %entry
%p_fptr1 = getelementptr inbounds %struct.fptr, %struct.fptr* %t_fptr, i32 0, i32 0, !dbg !39
store i32 (i32, i32)* @minus, i32 (i32, i32)** %p_fptr1, align 8, !dbg !41
br label %if.end

------predblock------

if.then:                                          ; preds = %entry
%p_fptr = getelementptr inbounds %struct.fptr, %struct.fptr* %t_fptr, i32 0, i32 0, !dbg !35
store i32 (i32, i32)* @plus, i32 (i32, i32)** %p_fptr, align 8, !dbg !37
br label %if.end, !dbg !38

%p_fptr = getelementptr inbounds %struct.fptr, %struct.fptr* %t_fptr, i32 0, i32 0, !dbg !35
%t_fptr = alloca %struct.fptr, align 8
%p_fptr1 = getelementptr inbounds %struct.fptr, %struct.fptr* %t_fptr, i32 0, i32 0, !dbg !39
%t_fptr = alloca %struct.fptr, align 8
%2 = load i32 (i32, i32)*, i32 (i32, i32)** %p_fptr5, align 8, !dbg !46
%p_fptr5 = getelementptr inbounds %struct.fptr, %struct.fptr* %t_fptr, i32 0, i32 0, !dbg !46
%t_fptr = alloca %struct.fptr, align 8
------predblock------

if.end:                                           ; preds = %if.else, %if.then
%p_fptr2 = getelementptr inbounds %struct.fptr, %struct.fptr* %t_fptr, i32 0, i32 0, !dbg !42
%1 = load i32 (i32, i32)*, i32 (i32, i32)** %p_fptr2, align 8, !dbg !42
%cmp3 = icmp ne i32 (i32, i32)* %1, null, !dbg !44
br i1 %cmp3, label %if.then4, label %if.end6, !dbg !45

%cmp3 = icmp ne i32 (i32, i32)* %1, null, !dbg !44
%1 = load i32 (i32, i32)*, i32 (i32, i32)** %p_fptr2, align 8, !dbg !42
%p_fptr2 = getelementptr inbounds %struct.fptr, %struct.fptr* %t_fptr, i32 0, i32 0, !dbg !42
%t_fptr = alloca %struct.fptr, align 8

in :
out :  t_fptr

in : t_fptr
out :  t_fptr

in : t_fptr
out :  t_fptr

in : t_fptr
out :  t_fptr

in : t_fptr
out :

in :
out :
----PrintResult---
----ENDPrintResult---
