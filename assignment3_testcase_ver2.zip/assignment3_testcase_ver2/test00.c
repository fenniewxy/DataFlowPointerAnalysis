#include <stdlib.h>

int plus(int a, int b) {
   return a+b;
}

int minus(int a,int b)
{
    return a-b;
}

int foo(int a,int b,int(* a_fptr)(int, int))
{
    return a_fptr(a,b);
}


int moo(char x)
{
    int (*af_ptr)(int ,int ,int(*)(int, int))=foo;
    int (*pf_ptr)(int,int)=0;
    if(x == '+'){
        pf_ptr=plus;
        af_ptr(1,2,pf_ptr);
        pf_ptr=minus;
    }
    af_ptr(1,2,pf_ptr);
    return 0;
}

//14 : plus, minus
//24 : foo
//27 : foo
------basicblock------

entry:
call void @llvm.dbg.value(metadata i32 %a, i64 0, metadata !11, metadata !12), !dbg !13
call void @llvm.dbg.value(metadata i32 %b, i64 0, metadata !14, metadata !12), !dbg !15
%add = add nsw i32 %a, %b, !dbg !16
ret i32 %add, !dbg !17

----Instruction---
%add = add nsw i32 %a, %b, !dbg !16

in :
out :
------basicblock------

entry:
call void @llvm.dbg.value(metadata i32 %a, i64 0, metadata !11, metadata !12), !dbg !13
call void @llvm.dbg.value(metadata i32 %b, i64 0, metadata !14, metadata !12), !dbg !15
%sub = sub nsw i32 %a, %b, !dbg !16
ret i32 %sub, !dbg !17

----Instruction---
%sub = sub nsw i32 %a, %b, !dbg !16

in :
out :
------basicblock------

entry:
call void @llvm.dbg.value(metadata i32 %a, i64 0, metadata !14, metadata !15), !dbg !16
call void @llvm.dbg.value(metadata i32 %b, i64 0, metadata !17, metadata !15), !dbg !18
call void @llvm.dbg.value(metadata i32 (i32, i32)* %a_fptr, i64 0, metadata !19, metadata !15), !dbg !20
%call = call i32 %a_fptr(i32 %a, i32 %b), !dbg !21
ret i32 %call, !dbg !22

----Instruction---
%call = call i32 %a_fptr(i32 %a, i32 %b), !dbg !21
----CallInst---
%call = call i32 %a_fptr(i32 %a, i32 %b), !dbg !21
function is null
14
function is null
14
argument

in :
out :
------basicblock------

entry:
call void @llvm.dbg.value(metadata i8 %x, i64 0, metadata !12, metadata !13), !dbg !14
call void @llvm.dbg.value(metadata i32 (i32, i32, i32 (i32, i32)*)* @foo, i64 0, metadata !15, metadata !13), !dbg !22
call void @llvm.dbg.value(metadata i32 (i32, i32)* null, i64 0, metadata !23, metadata !13), !dbg !24
%conv = sext i8 %x to i32, !dbg !25
%cmp = icmp eq i32 %conv, 43, !dbg !27
br i1 %cmp, label %if.then, label %if.end, !dbg !28


------succblock------

if.then:                                          ; preds = %entry
call void @llvm.dbg.value(metadata i32 (i32, i32)* @plus, i64 0, metadata !23, metadata !13), !dbg !24
%call = call i32 @foo(i32 1, i32 2, i32 (i32, i32)* @plus), !dbg !29
call void @llvm.dbg.value(metadata i32 (i32, i32)* @minus, i64 0, metadata !23, metadata !13), !dbg !24
br label %if.end, !dbg !31

------succblock------

if.end:                                           ; preds = %if.then, %entry
%pf_ptr.0 = phi i32 (i32, i32)* [ @minus, %if.then ], [ null, %entry ]
call void @llvm.dbg.value(metadata i32 (i32, i32)* %pf_ptr.0, i64 0, metadata !23, metadata !13), !dbg !24
%call2 = call i32 @foo(i32 1, i32 2, i32 (i32, i32)* %pf_ptr.0), !dbg !32
ret i32 0, !dbg !33

----Instruction---
%cmp = icmp eq i32 %conv, 43, !dbg !27
----Instruction---
%conv = sext i8 %x to i32, !dbg !25
------basicblock------

if.then:                                          ; preds = %entry
call void @llvm.dbg.value(metadata i32 (i32, i32)* @plus, i64 0, metadata !23, metadata !13), !dbg !24
%call = call i32 @foo(i32 1, i32 2, i32 (i32, i32)* @plus), !dbg !29
call void @llvm.dbg.value(metadata i32 (i32, i32)* @minus, i64 0, metadata !23, metadata !13), !dbg !24
br label %if.end, !dbg !31

------succblock------

if.end:                                           ; preds = %if.then, %entry
%pf_ptr.0 = phi i32 (i32, i32)* [ @minus, %if.then ], [ null, %entry ]
call void @llvm.dbg.value(metadata i32 (i32, i32)* %pf_ptr.0, i64 0, metadata !23, metadata !13), !dbg !24
%call2 = call i32 @foo(i32 1, i32 2, i32 (i32, i32)* %pf_ptr.0), !dbg !32
ret i32 0, !dbg !33

24 : foo
------basicblock------

if.end:                                           ; preds = %if.then, %entry
%pf_ptr.0 = phi i32 (i32, i32)* [ @minus, %if.then ], [ null, %entry ]
call void @llvm.dbg.value(metadata i32 (i32, i32)* %pf_ptr.0, i64 0, metadata !23, metadata !13), !dbg !24
%call2 = call i32 @foo(i32 1, i32 2, i32 (i32, i32)* %pf_ptr.0), !dbg !32
ret i32 0, !dbg !33

27 : foo
----Instruction---
%pf_ptr.0 = phi i32 (i32, i32)* [ @minus, %if.then ], [ null, %entry ]

in :
out :

in :
out :

in :
out :
----Instruction---
%add = add nsw i32 %a, %b, !dbg !16

in :
out :
----Instruction---
%sub = sub nsw i32 %a, %b, !dbg !16

in :
out :
----Instruction---
%call = call i32 %a_fptr(i32 %a, i32 %b), !dbg !21
----CallInst---
%call = call i32 %a_fptr(i32 %a, i32 %b), !dbg !21
function is null
14
function is null
14
argument
------basicblock------

entry:
call void @llvm.dbg.value(metadata i32 %a, i64 0, metadata !14, metadata !15), !dbg !16
call void @llvm.dbg.value(metadata i32 %b, i64 0, metadata !17, metadata !15), !dbg !18
call void @llvm.dbg.value(metadata i32 (i32, i32)* %a_fptr, i64 0, metadata !19, metadata !15), !dbg !20
%call = call i32 %a_fptr(i32 %a, i32 %b), !dbg !21
ret i32 %call, !dbg !22


in :
out :
----Instruction---
%cmp = icmp eq i32 %conv, 43, !dbg !27
----Instruction---
%conv = sext i8 %x to i32, !dbg !25
24 : foo
27 : foo
----Instruction---
%pf_ptr.0 = phi i32 (i32, i32)* [ @minus, %if.then ], [ null, %entry ]

in :
out :

in :
out :

in :
out :
24:foo
27:foo
func is NULL


_______






----Instruction---
%add = add nsw i32 %a, %b, !dbg !16

in :
out :
----Instruction---
%sub = sub nsw i32 %a, %b, !dbg !16

in :
out :
----Instruction---
%call = call i32 %a_fptr(i32 %a, i32 %b), !dbg !21
----CallInst---
%call = call i32 %a_fptr(i32 %a, i32 %b), !dbg !21
function is null
14
function is null
14
argument
offset:2

; Function Attrs: noinline nounwind uwtable
define i32 @foo(i32 %a, i32 %b, i32 (i32, i32)* %a_fptr) #0 !dbg !25 {
entry:
    call void @llvm.dbg.value(metadata i32 %a, i64 0, metadata !29, metadata !12), !dbg !30
    call void @llvm.dbg.value(metadata i32 %b, i64 0, metadata !31, metadata !12), !dbg !32
    call void @llvm.dbg.value(metadata i32 (i32, i32)* %a_fptr, i64 0, metadata !33, metadata !12), !dbg !34
    %call = call i32 %a_fptr(i32 %a, i32 %b), !dbg !35
    ret i32 %call, !dbg !36
    }
    
    ------basicblock------
    
entry:
    call void @llvm.dbg.value(metadata i32 %a, i64 0, metadata !14, metadata !15), !dbg !16
    call void @llvm.dbg.value(metadata i32 %b, i64 0, metadata !17, metadata !15), !dbg !18
    call void @llvm.dbg.value(metadata i32 (i32, i32)* %a_fptr, i64 0, metadata !19, metadata !15), !dbg !20
    %call = call i32 %a_fptr(i32 %a, i32 %b), !dbg !21
    ret i32 %call, !dbg !22
    
    
    in :
    out :
    14:plus
    ----Instruction---
    %cmp = icmp eq i32 %conv, 43, !dbg !27
    ----Instruction---
    %conv = sext i8 %x to i32, !dbg !25
    24 : foo
    27 : foo
    ----Instruction---
    %pf_ptr.0 = phi i32 (i32, i32)* [ @minus, %if.then ], [ null, %entry ]
    
    in :
    out :
    
    in :
    out :
    
    in :
    out :
    24:foo
    27:foo
    func is NULL
