#include <stdlib.h>
int plus(int a, int b) {
   return a+b;
}

int minus(int a, int b) {
   return a-b;
}

int clever(int x) {
    int (*a_fptr)(int, int) = plus;
    int (*s_fptr)(int, int) = minus;
    int (*t_fptr)(int, int) = minus;

    int op1=1, op2=2;

    if (x == 3) {
       t_fptr = a_fptr;
    } 

    if (t_fptr != NULL) {
       unsigned result = t_fptr(op1, op2);
    }  
   return 0;
}

// 22 : plus, minus 
------basicblock------

entry:
call void @llvm.dbg.value(metadata i32 %a, i64 0, metadata !13, metadata !14), !dbg !15
call void @llvm.dbg.value(metadata i32 %b, i64 0, metadata !16, metadata !14), !dbg !17
%add = add nsw i32 %a, %b, !dbg !18
ret i32 %add, !dbg !19


in :
out :
------basicblock------

entry:
call void @llvm.dbg.value(metadata i32 %a, i64 0, metadata !13, metadata !14), !dbg !15
call void @llvm.dbg.value(metadata i32 %b, i64 0, metadata !16, metadata !14), !dbg !17
%sub = sub nsw i32 %a, %b, !dbg !18
ret i32 %sub, !dbg !19


in :
out :
------basicblock------

entry:
call void @llvm.dbg.value(metadata i32 %x, i64 0, metadata !13, metadata !14), !dbg !15
call void @llvm.dbg.value(metadata i32 (i32, i32)* @plus, i64 0, metadata !16, metadata !14), !dbg !20
call void @llvm.dbg.value(metadata i32 (i32, i32)* @minus, i64 0, metadata !21, metadata !14), !dbg !22
call void @llvm.dbg.value(metadata i32 (i32, i32)* @minus, i64 0, metadata !23, metadata !14), !dbg !24
call void @llvm.dbg.value(metadata i32 1, i64 0, metadata !25, metadata !14), !dbg !26
call void @llvm.dbg.value(metadata i32 2, i64 0, metadata !27, metadata !14), !dbg !28
%cmp = icmp eq i32 %x, 3, !dbg !29
br i1 %cmp, label %if.then, label %if.end, !dbg !31

------succ block------

if.then:                                          ; preds = %entry
call void @llvm.dbg.value(metadata i32 (i32, i32)* @plus, i64 0, metadata !23, metadata !14), !dbg !24
br label %if.end, !dbg !32

------succ block------

if.end:                                           ; preds = %if.then, %entry
%t_fptr.0 = phi i32 (i32, i32)* [ @plus, %if.then ], [ @minus, %entry ]
call void @llvm.dbg.value(metadata i32 (i32, i32)* %t_fptr.0, i64 0, metadata !23, metadata !14), !dbg !24
%cmp1 = icmp ne i32 (i32, i32)* %t_fptr.0, null, !dbg !34
br i1 %cmp1, label %if.then2, label %if.end3, !dbg !36

------basicblock------

if.then:                                          ; preds = %entry
call void @llvm.dbg.value(metadata i32 (i32, i32)* @plus, i64 0, metadata !23, metadata !14), !dbg !24
br label %if.end, !dbg !32

------succ block------

if.end:                                           ; preds = %if.then, %entry
%t_fptr.0 = phi i32 (i32, i32)* [ @plus, %if.then ], [ @minus, %entry ]
call void @llvm.dbg.value(metadata i32 (i32, i32)* %t_fptr.0, i64 0, metadata !23, metadata !14), !dbg !24
%cmp1 = icmp ne i32 (i32, i32)* %t_fptr.0, null, !dbg !34
br i1 %cmp1, label %if.then2, label %if.end3, !dbg !36

------basicblock------

if.end:                                           ; preds = %if.then, %entry
%t_fptr.0 = phi i32 (i32, i32)* [ @plus, %if.then ], [ @minus, %entry ]
call void @llvm.dbg.value(metadata i32 (i32, i32)* %t_fptr.0, i64 0, metadata !23, metadata !14), !dbg !24
%cmp1 = icmp ne i32 (i32, i32)* %t_fptr.0, null, !dbg !34
br i1 %cmp1, label %if.then2, label %if.end3, !dbg !36

------succ block------

if.then2:                                         ; preds = %if.end
%call = call i32 %t_fptr.0(i32 1, i32 2), !dbg !37
call void @llvm.dbg.value(metadata i32 %call, i64 0, metadata !39, metadata !14), !dbg !41
br label %if.end3, !dbg !42

------succ block------

if.end3:                                          ; preds = %if.then2, %if.end
ret i32 0, !dbg !43

------basicblock------

if.then2:                                         ; preds = %if.end
%call = call i32 %t_fptr.0(i32 1, i32 2), !dbg !37
call void @llvm.dbg.value(metadata i32 %call, i64 0, metadata !39, metadata !14), !dbg !41
br label %if.end3, !dbg !42

------succ block------

if.end3:                                          ; preds = %if.then2, %if.end
ret i32 0, !dbg !43

------basicblock------

if.end:                                           ; preds = %if.then, %entry
%t_fptr.0 = phi i32 (i32, i32)* [ @plus, %if.then ], [ @minus, %entry ]
call void @llvm.dbg.value(metadata i32 (i32, i32)* %t_fptr.0, i64 0, metadata !23, metadata !14), !dbg !24
%cmp1 = icmp ne i32 (i32, i32)* %t_fptr.0, null, !dbg !34
br i1 %cmp1, label %if.then2, label %if.end3, !dbg !36

------succ block------

if.then2:                                         ; preds = %if.end
%call = call i32 %t_fptr.0(i32 1, i32 2), !dbg !37
call void @llvm.dbg.value(metadata i32 %call, i64 0, metadata !39, metadata !14), !dbg !41
br label %if.end3, !dbg !42

------succ block------

if.end3:                                          ; preds = %if.then2, %if.end
ret i32 0, !dbg !43

------basicblock------

if.end3:                                          ; preds = %if.then2, %if.end
ret i32 0, !dbg !43

